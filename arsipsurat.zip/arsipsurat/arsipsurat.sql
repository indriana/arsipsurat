-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2021 at 01:18 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arsipsurat`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_jenis`
--

CREATE TABLE `tb_jenis` (
  `id` int(2) NOT NULL,
  `jenis_surat` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_jenis`
--

INSERT INTO `tb_jenis` (`id`, `jenis_surat`) VALUES
(1, 'Undangan'),
(2, 'Surat Resmi'),
(3, 'Surat Dinas');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `id` int(2) NOT NULL,
  `keterangan` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`id`, `keterangan`) VALUES
(1, 'Surat Masuk'),
(2, 'Surat Keluar');

-- --------------------------------------------------------

--
-- Table structure for table `tb_surat`
--

CREATE TABLE `tb_surat` (
  `id_surat` int(11) NOT NULL,
  `no_surat` varchar(20) NOT NULL,
  `hal` varchar(20) NOT NULL,
  `lampiran` varchar(10) NOT NULL,
  `tujuan` varchar(20) NOT NULL,
  `id_jenis` int(2) NOT NULL,
  `id_keterangan` int(2) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_surat`
--

INSERT INTO `tb_surat` (`id_surat`, `no_surat`, `hal`, `lampiran`, `tujuan`, `id_jenis`, `id_keterangan`, `tanggal`) VALUES
(3, '21', 'Izin', 'lokasi', 'Check contoh', 2, 2, '2018-10-13'),
(6, '06', 'Lamaran', 'Rundown', 'Bapake', 3, 1, '2018-10-24'),
(8, '80', 'Udangan', 'List tamu', 'Hotel', 1, 1, '2018-10-15'),
(9, '1234', 'contoh', 'contoh', 'contoh', 1, 2, '2018-10-26'),
(30, 'contoh678', 'contoh', 'Tutu', 'Staff', 1, 1, '2018-10-26'),
(34, 'contoh saja', 'contoh saja', '-', 'contoh saja', 1, 2, '2018-10-26'),
(35, 'dgsdgs', 'lamaran', '-', 'contoh', 1, 1, '2018-10-27'),
(36, 'd78i', 'wow', 'takmengert', 'Semua Pegawai', 1, 1, '2018-10-26'),
(38, '1', 'qwew', 'sfsd', 'dsfsd', 1, 1, '2018-07-26'),
(39, 'gdg', 'safasf', 'safas', 'sfas', 2, 1, '2018-10-26'),
(41, 'salsa', 'Saf', 'Jumlah', 'Jamaah', 1, 2, '2018-10-26'),
(42, 'sfsa', 'sfafas', 'safas', 'sfasf', 1, 1, '2018-10-26'),
(43, '12ah', 'Urgent', 'Dana', 'wkwkwk', 1, 1, '2018-10-26'),
(45, 'mngb', 'fgjgf', 'gfjgfj', 'ffdgj', 1, 2, '2018-10-26');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(4) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `nama`, `username`, `password`, `level`) VALUES
(1, 'Indri', 'admin', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_jenis`
--
ALTER TABLE `tb_jenis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_surat`
--
ALTER TABLE `tb_surat`
  ADD PRIMARY KEY (`id_surat`),
  ADD KEY `id_jenis` (`id_jenis`),
  ADD KEY `id_keterangan` (`id_keterangan`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_jenis`
--
ALTER TABLE `tb_jenis`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_surat`
--
ALTER TABLE `tb_surat`
  MODIFY `id_surat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_surat`
--
ALTER TABLE `tb_surat`
  ADD CONSTRAINT `tb_surat_ibfk_1` FOREIGN KEY (`id_jenis`) REFERENCES `tb_jenis` (`id`),
  ADD CONSTRAINT `tb_surat_ibfk_2` FOREIGN KEY (`id_keterangan`) REFERENCES `tb_kategori` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
